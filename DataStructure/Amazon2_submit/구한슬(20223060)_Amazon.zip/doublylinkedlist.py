from BidirectNode import *

class CircularDoublyLinkedList:
    def __init__(self):
        self.__head = BidirectNode("dummy", None, None, None)
        self.__head.prev = self.__head
        self.__head.next = self.__head
        self.__numItems = 0

    def insert(self, i:int, key, value) -> None:
        if (i >= 0 and i <= self.__numItems):
            prev = self.getNode(i-1)
            newNode = BidirectNode(key, value, prev, prev.next)
            newNode.next.prev = newNode
            prev.next = newNode
            self.__numItems += 1
        else:
            print("index", i, ":out of bound in insert()") #필요 시 에러 처리

    def append(self, key, value) -> None:
        prev = self.__head.prev
        newNode = BidirectNode(key, value, prev, self.__head)
        prev.next = newNode
        self.__head.prev = newNode
        self.__numItems += 1

    def pop(self, *args) :
        if self.isEmpty() :
            return None
        if len(args) != 0 :
            i=args[0]
        if len(args) == 0 or i == -1 :
            i = self.__numItems-1
        if (i>=0 and i<= self.__numItems - 1) :
            curr = self.getNode(i)
            retItem = curr.item
            curr.prev.next = curr.next
            curr.next.prev = curr.prev
            self.__numItems -= 1
            return retItem
        else :
            return None
        
    def remove(self, x):
        curr = self.__findNode(x)
        if curr != None:
            curr.prev.next = curr.next
            curr.next.prev = curr.prev
            self.__numItems -= 1
            return x
        else:
            return None
        
    def get(self, *args) :
        if self.isEmpty() : return None

        if len(args) != 0 :
            i = args[0]
        if len(args) == 0 or i == -1 :
            i = self.__numItems - 1
        if (i>=0 and i <= self.__numItems - 1) :
            return self.getNode(i).item
        else:
            return None
        
    def index(self, x) -> int:
        cnt = 0
        for element in self:
            if element == x:
                return cnt
            cnt += 1
        return -12345
    
    def isEmpty(self) -> bool:
        return self.__numItems == 0
    
    def size(self) -> int:
        return self.__numItems
    
    def clear(self):
        self.__head = BidirectNode("dummy", None, None)
        self.__head.prev = self.__head
        self.__head.next = self.__head
        self.__numItems = 0

    def count(self, x) -> int:
        cnt = 0
        for element in self:
            if element == x:
                cnt += 1
        return cnt
    
    def extend(self, a): #a는 순회 가능한 모든 객체
        for element in a:
            self.append(element)

    def copy(self) -> 'CircularDoublyLinkedList':
        a = CircularDoublyLinkedList()
        for element in self:
            a.append(element)
        return a
    
    def reverse(self) -> None:
        prev = self.__head; curr = prev.next; next = curr.next
        self.__head.next = prev.prev; self.__head.prev = curr
        for i in range(self.__numItems):
            curr.next = prev; curr.prev = next
            prev = curr; curr = next; next = next.next
    
    def sort(self) -> None:
        a= []
        for element in self:
            a.append(element)
        a.sort()
        self.clear()
        for element in a:
            self.append(element)
            
    def __findNode(self,x) -> BidirectNode :
        curr = self.__head.next
        while curr != self.__head :

            if curr.item == x:
                return curr
            else :
                curr = curr.next
        return None
    
    def getNode(self, i:int) -> BidirectNode:
        curr = self.__head #더미 헤드, index: -1
        for index in range(i+1):
            curr = curr.next
        return curr
    
    def printList(self) -> None:
        for element in self:
            print(element, end = ' ')
        print()

    # def filter(self, found_list): #find 함수를 가진 class 객체를 인자로 받음
    #     return found_list.find(self)
    def filter(self, flist): #find 함수를 가진 class 객체를 인자로 받음
        return flist.find(self)

    def __iter__(self):  #generating iterator and return
        return CircularDoublyLinkedListIterator(self)
    
class CircularDoublyLinkedListIterator:
    def __init__(self, alist):
        self.__head = alist.getNode(-1)  #더미 헤드
        self.iterPosition = self.__head.next  #0번 노드
    def __next__(self):
        if self.iterPosition == self.__head: #순환 끝
            raise StopIteration
        else:  #현재 원소를 리턴하면서 다음 원소로 이동
            key = self.iterPosition.key
            value = self.iterPosition.value
            self.iterPosition = self.iterPosition.next
            return key, value
        

class CircularDoublyLinkedListFilter():
    def __init__(self): #뭘 받아와? node 내용, 걍 연결리스트?
        pass

    def find(self, dataset): #상품명 맞는거 찾아서 list로 return 해야겠다
        #그럼 다 for문으로 돌려서 list에 저장?
        found_list = []
        for element in dataset:
            if int(element[1]) >= 15:
                found_list.append({element[0] : element[1]})
        return found_list
    

            
